"""Medical Schedule Management System - Core Package"""
